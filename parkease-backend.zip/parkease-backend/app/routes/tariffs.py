from fastapi import APIRouter
from app.models.tariff import Tariff
from app.config import supabase

router = APIRouter(prefix="/tariffs", tags=["Tarifas"])

@router.post("/")
def add_tariff(tariff: Tariff):
    data, _ = supabase.table("tariffs").insert(tariff.dict()).execute()
    return {"message": "Tarifa agregada", "data": data}

@router.get("/")
def list_tariffs():
    data, _ = supabase.table("tariffs").select("*").execute()
    return data
