from fastapi import APIRouter
from app.config import supabase

router = APIRouter(prefix="/reports", tags=["Reportes"])

@router.get("/daily")
def daily_report():
    reservas, _ = supabase.table("reservations").select("*").execute()
    accesos, _ = supabase.table("access_logs").select("*").execute()
    return {
        "resumen": {
            "total_reservas": len(reservas),
            "total_accesos": len(accesos)
        }
    }
