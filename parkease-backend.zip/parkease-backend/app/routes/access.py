from fastapi import APIRouter
from app.models.access import AccessLog
from app.config import supabase
from datetime import datetime

router = APIRouter(prefix="/access", tags=["Accesos"])

@router.post("/")
def register_access(log: AccessLog):
    log.timestamp = datetime.now()
    data, _ = supabase.table("access_logs").insert(log.dict()).execute()
    return {"message": f"{log.tipo.capitalize()} registrada", "data": data}

@router.get("/")
def get_logs():
    data, _ = supabase.table("access_logs").select("*").execute()
    return data
