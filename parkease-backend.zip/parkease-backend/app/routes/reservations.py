from fastapi import APIRouter
from app.models.reservation import Reservation
from app.config import supabase

router = APIRouter(prefix="/reservations", tags=["Reservas"])

@router.post("/")
def create_reservation(reservation: Reservation):
    data, _ = supabase.table("reservations").insert(reservation.dict()).execute()
    return {"message": "Reserva creada", "data": data}

@router.get("/")
def list_reservations():
    data, _ = supabase.table("reservations").select("*").execute()
    return data
