from fastapi import APIRouter
from app.models.user import User
from app.config import supabase

router = APIRouter(prefix="/users", tags=["Usuarios"])

@router.post("/")
def create_user(user: User):
    data, _ = supabase.table("users").insert(user.dict()).execute()
    return {"message": "Usuario creado", "data": data}

@router.get("/")
def get_users():
    data, _ = supabase.table("users").select("*").execute()
    return data
