from pydantic import BaseModel, EmailStr
from typing import Optional

class User(BaseModel):
    id: Optional[str] = None
    nombre: str
    email: EmailStr
    contrasena: str
    rol: str  # "Administrador", "Operador", "Usuario"
