from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class AccessLog(BaseModel):
    id: Optional[str] = None
    reserva_id: str
    tipo: str  # entrada/salida
    timestamp: Optional[datetime] = None
