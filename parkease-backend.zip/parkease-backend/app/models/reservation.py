from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class Reservation(BaseModel):
    id: Optional[str] = None
    user_id: str
    espacio_id: str
    fecha: datetime
    estado: str = "activa"
