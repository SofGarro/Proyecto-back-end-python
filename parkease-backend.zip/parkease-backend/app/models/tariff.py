from pydantic import BaseModel
from typing import Optional

class Tariff(BaseModel):
    id: Optional[str] = None
    tipo: str  # hora/día/mes
    precio: float
