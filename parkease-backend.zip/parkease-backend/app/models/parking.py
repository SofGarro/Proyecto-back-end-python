from pydantic import BaseModel
from typing import Optional

class ParkingSpace(BaseModel):
    id: Optional[str] = None
    nivel: int
    numero: int
    estado: str = "disponible"
