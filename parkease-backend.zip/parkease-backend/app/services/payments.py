def procesar_pago(user_id: str, monto: float):
    # Aquí podrías integrar Stripe, PayPal o un mock
    return {"estado": "exitoso", "monto": monto}
