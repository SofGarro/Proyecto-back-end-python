def enviar_notificacion(email: str, mensaje: str):
    print(f"📩 Notificación enviada a {email}: {mensaje}")
    return True
