from datetime import datetime

def formatear_fecha(fecha: datetime):
    return fecha.strftime("%d/%m/%Y %H:%M:%S")
