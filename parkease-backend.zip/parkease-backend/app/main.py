from fastapi import FastAPI
from app.routes import users, tariffs, reservations, access, reports

app = FastAPI(
    title="ParkEase API",
    description="Sistema de Gestión de Estacionamientos ParkEase",
    version="1.0.0"
)

# Rutas principales
app.include_router(users.router)
app.include_router(tariffs.router)
app.include_router(reservations.router)
app.include_router(access.router)
app.include_router(reports.router)

@app.get("/")
def home():
    return {"message": "Bienvenido a la API de ParkEase 🚗"}
